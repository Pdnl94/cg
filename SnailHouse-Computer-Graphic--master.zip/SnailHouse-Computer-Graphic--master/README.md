# SnailHouse-Computer-Graphic-
Assignment for computer graphics class.
